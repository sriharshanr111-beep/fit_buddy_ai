# FitBuddy – AI Fitness Plan Generator (FastAPI + Gemini + SQLite)

## Setup
1. Python 3.10+ installed.
2. `python -m venv venv` then activate (`venv\Scripts\activate` on Windows, `source venv/bin/activate` on Mac/Linux)
3. `pip install -r requirements.txt`
4. Copy `.env.example` to `.env` and paste your Gemini API key (https://aistudio.google.com/apikey)
5. `uvicorn app.main:app --reload`
6. Open http://127.0.0.1:8000  (API docs: /docs)

## Tests (no API key needed – Gemini is mocked)
`pytest -v`
