"""Shared helper that talks to Google's Gemini API (google-genai SDK)."""
import re
import time

from . import config


class GeminiError(RuntimeError):
    """Raised when the Gemini API cannot produce a usable answer."""


_client = None


def get_client():
    global _client
    if not config.GOOGLE_API_KEY:
        raise GeminiError(
            "GOOGLE_API_KEY is missing. Create a .env file (see .env.example) and add your Gemini API key."
        )
    if _client is None:
        from google import genai  # imported here so the app can start even without the key

        _client = genai.Client(api_key=config.GOOGLE_API_KEY)
    return _client


def clean_text(text: str) -> str:
    """Remove markdown symbols so the text looks clean inside <pre> blocks."""
    text = text.replace("\r\n", "\n")
    text = re.sub(r"\*\*(.*?)\*\*", r"\1", text)                  # **bold**
    text = re.sub(r"^[ \t]{0,3}#{1,6}[ \t]*", "", text, flags=re.M)      # # headings
    text = re.sub(r"^[ \t]*[\*\-][ \t]+", "• ", text, flags=re.M)        # bullets
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def generate_text(model: str, prompt: str, retries: int = 2) -> str:
    """Call Gemini and return cleaned text. Retries briefly on temporary errors."""
    client = get_client()
    last_error = None
    for attempt in range(retries + 1):
        try:
            response = client.models.generate_content(model=model, contents=prompt)
            text = (response.text or "").strip()
            if not text:
                raise GeminiError("The AI returned an empty response. Please try again.")
            return clean_text(text)
        except GeminiError:
            raise
        except Exception as exc:  # network / quota / model-name errors
            last_error = exc
            if attempt < retries:
                time.sleep(1.5 * (attempt + 1))
    raise GeminiError(f"Gemini request failed for model '{model}': {last_error}")
